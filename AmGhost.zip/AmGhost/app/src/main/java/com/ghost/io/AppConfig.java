package com.ghost.io;

/**
 * Created by Roy Wati on 11/3/2017.
 */

public class AppConfig {

    public static int[] landing_images={R.drawable.new_dream,R.drawable.my_dreams,R.drawable.contact,R.drawable.backup};
    public static String[] landing_text={"New Dream","My Dreams","Contact Psyc","Backup and Restore"};

    public static int[] picture_dream={R.drawable.creepy,R.drawable.flying,R.drawable.animals,R.drawable.flowers};

    public static int selected_dream;

    public static String[] data;
    public static String[] date;
    public static int[] pic_id;




}
