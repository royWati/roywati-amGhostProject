package com.ghost.io.newdream;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;

import com.ghost.io.AppConfig;
import com.ghost.io.LandingPage;
import com.ghost.io.R;
import com.ghost.io.dataController.sqlite_database;
import com.ghost.io.landingPageAdapter;

/**
 * Created by Roy Wati on 11/3/2017.
 */

public class new_dream_data extends AppCompatActivity {

    Button btn_save;
    EditText text_data;
    DatePicker datePicker;

    sqlite_database db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_dream_data);

        db=new sqlite_database(this);

        btn_save=(Button)findViewById(R.id.save);
        text_data=(EditText)findViewById(R.id.edit_dream);
        datePicker=(DatePicker)findViewById(R.id.date_of);

      if( db.insertData(text_data.toString(),datePicker.toString(),AppConfig.selected_dream)){
          Toast.makeText(getApplicationContext(),"data inserted successfully",Toast.LENGTH_SHORT).show();
          startActivity(new Intent(new_dream_data.this, LandingPage.class));
      }else{
          Toast.makeText(getApplicationContext(),"data not inserted",Toast.LENGTH_SHORT).show();
      }




    }
}
