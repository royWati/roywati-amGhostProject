package com.ghost.io.dataController;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Roy Wati on 11/3/2017.
 */

public class sqlite_database extends SQLiteOpenHelper {

    public static String database_name="dreams_db";
    public static String table_name="tb_dreams";
    public static String col_1="id";
    public static String col_2="dream_data";
    public static String col_3="picture_select";
    public static String col_4="date_of";



    public sqlite_database(Context context) {
        super(context, database_name,null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table "+ table_name+" (id INTEGER PRIMARY KEY AUTOINCREMENT,dream_data VARCHAR(1500)," +
                "picture_select INTEGER,date_of VARCHAR(50))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS"+database_name);
        onCreate(sqLiteDatabase);
    }

    public boolean insertData(String data,String date,int picture_select)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(col_2,data);
        contentValues.put(col_3,picture_select);
        contentValues.put(col_4,date);
        long result=db.insert(table_name,null,contentValues);
        if(result==-1)
            return false;
        else
            return true;

    }

    public Cursor getAllData()
    {
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor res=db.rawQuery("select * from"+table_name,null);
        return res;
    }
}
