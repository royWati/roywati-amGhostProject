package com.ghost.io;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;

import com.ghost.io.mydreams.MyDreams;
import com.ghost.io.newdream.NewDream;

/**
 * Created by Roy Wati on 11/3/2017.
 */

public class LandingPage extends AppCompatActivity {

    GridView gridView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.landing_page);

        gridView=(GridView)findViewById(R.id.grid_view);

        gridView.setAdapter(new landingPageAdapter(LandingPage.this,AppConfig.landing_images,AppConfig.landing_text));
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int pos, long l) {
                int i= (int) adapterView.getItemIdAtPosition(pos);
                switch (i){
                    case 0:
                        startActivity(new Intent(LandingPage.this,NewDream.class));
                        break;
                    case 1:
                        startActivity(new Intent(LandingPage.this,MyDreams.class));
                        break;
                    case 2:

                        break;
                    case 3:

                        break;
                }
            }
        });
    }
}
