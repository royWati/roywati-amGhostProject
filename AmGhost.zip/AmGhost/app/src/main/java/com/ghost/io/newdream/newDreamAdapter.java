package com.ghost.io.newdream;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.ghost.io.R;

/**
 * Created by Roy Wati on 11/3/2017.
 */

public class newDreamAdapter extends BaseAdapter {

    int[] images;
    String[] texts;
    public static LayoutInflater inflater;
    Context context;


    public newDreamAdapter(Activity activity, int[] images, String[] texts){
        context=activity;
        this.images=images;
        this.texts=texts;
        inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    @Override
    public int getCount() {
        return images.length;
    }


    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view=inflater.inflate(R.layout.custom_landing_grid,null);
        TextView thisText=(TextView)view.findViewById(R.id.custom_text);
        ImageView image=(ImageView)view.findViewById(R.id.custom_img);

        thisText.setText(texts[i]);
        try{
            image.setImageResource(images[i]);
        }catch (OutOfMemoryError e){
            image.setImageResource(R.mipmap.ic_launcher);
        }

        return view;
    }
}
