package com.ghost.io.newdream;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;

import com.ghost.io.AppConfig;
import com.ghost.io.R;
import com.ghost.io.landingPageAdapter;

/**
 * Created by Roy Wati on 11/3/2017.
 */

public class NewDream extends AppCompatActivity {

    GridView gridView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_dream);

        gridView=(GridView)findViewById(R.id.new_dream_gridView);

        gridView.setAdapter(new landingPageAdapter(NewDream.this, AppConfig.landing_images,AppConfig.landing_text));
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int pos, long l) {
                AppConfig.selected_dream= (int) adapterView.getItemIdAtPosition(pos);
                startActivity(new Intent(NewDream.this,new_dream_data.class));

            }
        });
    }
}
