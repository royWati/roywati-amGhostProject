package com.ghost.io.mydreams;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.ghost.io.AppConfig;
import com.ghost.io.R;

/**
 * Created by Roy Wati on 11/3/2017.
 */

public class mydreamsAdapter extends BaseAdapter {

    int[] pic_id;
    String[] data,date;

    public static LayoutInflater inflater;
    Context context;

    public mydreamsAdapter(Activity activity, int[] pic_id, String[] data,String[] date){
        context=activity;
        this.pic_id=pic_id;
        this.data=data;
        this.date=date;
        inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    @Override
    public int getCount() {
        return pic_id.length;
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view=inflater.inflate(R.layout.custom_landing_grid,null);
        TextView thisText=(TextView)view.findViewById(R.id.custom_text);
        TextView date_of=(TextView)view.findViewById(R.id.daters);
        ImageView image=(ImageView)view.findViewById(R.id.custom_img);

        thisText.setText(data[i]);
        date_of.setText(date[i]);
        try{
            image.setImageResource(AppConfig.picture_dream[pic_id[i]]);
        }catch (OutOfMemoryError e){
            image.setImageResource(R.mipmap.ic_launcher);
        }

        return view;
    }
}
