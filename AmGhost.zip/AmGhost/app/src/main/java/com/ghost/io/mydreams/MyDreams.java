package com.ghost.io.mydreams;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.ghost.io.AppConfig;
import com.ghost.io.LandingPage;
import com.ghost.io.R;
import com.ghost.io.dataController.sqlite_database;
import com.ghost.io.newdream.new_dream_data;

import java.util.List;

/**
 * Created by Roy Wati on 11/3/2017.
 */

public class MyDreams extends AppCompatActivity {

    ListView listView;
    SearchView searchView;
    sqlite_database db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.my_dreams);

        db=new sqlite_database(this);

        searchView=(SearchView)findViewById(R.id.search);
        listView=(ListView) findViewById(R.id.listOfItems);

        try{
            Cursor cursor=db.getAllData();

            if(cursor.getCount()==0){
                Toast.makeText(this, "no record found", Toast.LENGTH_SHORT).show();
            }else{
                if (cursor.moveToFirst()) {
                    AppConfig.date = new String[cursor.getCount()];
                    AppConfig.data = new String[cursor.getCount()];
                    AppConfig.pic_id = new int[cursor.getCount()];

                }
                do {
                    int i = 0;
                    //passing data to the array
                    AppConfig.data[i] = cursor.getString(1);
                    AppConfig.date[i] = cursor.getString(2);
                    AppConfig.pic_id[i] = cursor.getInt(3);

                    i++;
                } while (cursor.moveToNext());

            }
        }catch(Exception e){
            e.getMessage();
        }

        listView.setAdapter(new mydreamsAdapter(MyDreams.this,AppConfig.pic_id,AppConfig.data,AppConfig.date));

        searchView.setOnQueryTextFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                return;
            }
        });
    }
}